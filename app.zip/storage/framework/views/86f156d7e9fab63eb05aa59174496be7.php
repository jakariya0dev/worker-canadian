<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="min-vh-100 d-flex justify-content-md-center align-items-center">
                <div class="card m-auto " style="width: 22rem;">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="my-3 text-center card-title">User Profile</h5>
                        <br>
                        <form action="<?php echo e(route('user.bio')); ?>">
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input name="user-email" type="email" class="form-control" id="email" placeholder="name@example.com">
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">User Password</label>
                                <input name="user-password" type="password" class="form-control" id="password">
                            </div>

                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary mb-3">Confirm identity</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.user.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-client\worker-canadian\resources\views/backend/user/search-bio.blade.php ENDPATH**/ ?>