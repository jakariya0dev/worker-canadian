<?php $__env->startSection('content'); ?>

    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Phone</th>
            <th scope="col">Actions</th>
            
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->mobile); ?></td>
                <th scope="col">
                  <a href="<?php echo e(route('bio.view', $user->id)); ?>" class="btn btn-sm btn-primary">View</a>
                  <a href="<?php echo e(route('bio.edit', $user->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                  <a href="<?php echo e(route('bio.delete', $user->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
              </th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
      <?php echo e($users->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('backend.admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-client\worker-canadian\resources\views/backend/admin/all-bio.blade.php ENDPATH**/ ?>